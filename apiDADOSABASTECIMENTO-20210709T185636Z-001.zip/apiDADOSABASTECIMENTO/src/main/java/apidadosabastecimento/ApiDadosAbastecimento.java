package apidadosabastecimento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiDadosAbastecimento {

	public static void main(String[] args) {
		SpringApplication.run(ApiDadosAbastecimento.class, args);
		System.out.println("porta:1805");		
	}

}
