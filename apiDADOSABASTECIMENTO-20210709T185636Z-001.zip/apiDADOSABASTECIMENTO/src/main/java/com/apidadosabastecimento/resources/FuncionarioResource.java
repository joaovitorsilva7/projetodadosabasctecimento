package com.apidadosabastecimento.resources;

public class FuncionarioResource {

}
