package com.apidadosabastecimento.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.apidadosabastecimento.domain.Operador;

@Repository
public interface IOperadorRepository extends JpaRepository<Operador, Long>{

	//save
	//delete
	//findAll()
}